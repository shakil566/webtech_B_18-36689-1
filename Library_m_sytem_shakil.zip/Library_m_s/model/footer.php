<!DOCTYPE html>
<html lang="en">
<head>
<style>
body{
	
	text-align:center;
}

</style>
</head>
<body >
    <footer style= position: fixed;>
		
		<p1>Copyright &copy; 2021 Library Management system (Shakil Hossen)</p1>
	</footer>
</body>
</html>