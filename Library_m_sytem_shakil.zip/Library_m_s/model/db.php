
<?php
$conn = mysqli_connect("localhost","root","","library");

if(!$conn)
{
	echo "Database connection failed...";
}
?>