 <!DOCTYPE HTML>  
<html>
<head>
<style>


div,div.ft{
  margin-left: 200px;
  padding: 1px 16px;

}

</style>
</head>
<?php include "include2.php"; ?>
<body style="background:#CCC;"> 


 <title>Notice</title> 
<div  style="font-size:40px">
  No notice availabe
     
</div>

<div class="ft">
<br><br>

<?php include "../model/footer.php"; ?>
</div>
</body>
</html>


