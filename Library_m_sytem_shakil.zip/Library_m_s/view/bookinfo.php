
<!DOCTYPE HTML>  
<html>
<head>
<style>

.pic{
	 margin-left: 200px;
  padding: 1px 16px;

}
	
</style>
</head>

<body style="background:#CCC;"> 


<?php include "../view/include2.php"; ?>


<div class="pic">
<?php include "../model/header.php"; ?>
        <title>Books Information</title>  <br>
<a href="fst.php"><img src="../img/cse.png"height="100" width="690" title="Computer Science and Engineering"></a><br><br>
<a href="fe.php"><img src="../img/eee.png"height="100" width="690" title="Electrical and Electronic Engineering"></a><br><br>
<a href="fba.php"><img src="../img/bba.png"height="100" width="690" title="Business Administration"></a><br><br>
<a href="ajax.php"><img src="../img/search.png"height="80" width="490" title="Search Books"></a><br>


<br><br>

<?php include "../model/footer.php"; ?>

</div>
</body>
</html>
